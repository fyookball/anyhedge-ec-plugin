from electroncash.i18n import _

fullname = 'anyhedge'
description = _('Anyhedge POC plugin')
available_for = ['qt']
